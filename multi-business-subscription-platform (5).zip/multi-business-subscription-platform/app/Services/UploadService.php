<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Config;
use RuntimeException;

class UploadService
{
    public static function image(string $field, string $directory, ?string $existing = null): ?string
    {
        if (empty($_FILES[$field]) || !is_array($_FILES[$field])) {
            return $existing;
        }

        $file = $_FILES[$field];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return $existing;
        }

        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Image upload failed. Please choose another file.');
        }

        $maxMb = Config::int('UPLOAD_MAX_MB', 3);
        $maxBytes = $maxMb * 1024 * 1024;
        if (($file['size'] ?? 0) > $maxBytes) {
            throw new RuntimeException('Image must not exceed ' . $maxMb . ' MB.');
        }

        $tmpName = (string) $file['tmp_name'];
        if (!is_uploaded_file($tmpName)) {
            throw new RuntimeException('Invalid uploaded file.');
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($tmpName);
        $allowed = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
        ];

        if (!isset($allowed[$mime])) {
            throw new RuntimeException('Only JPG, PNG, WEBP or GIF images are allowed.');
        }

        $targetDir = trim($directory, '/');
        $absoluteDir = PUBLIC_PATH . DIRECTORY_SEPARATOR . $targetDir;
        if (!is_dir($absoluteDir)) {
            mkdir($absoluteDir, 0775, true);
        }

        $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
        $absolutePath = $absoluteDir . DIRECTORY_SEPARATOR . $filename;

        if (!move_uploaded_file($tmpName, $absolutePath)) {
            throw new RuntimeException('Could not save uploaded image.');
        }

        return $targetDir . '/' . $filename;
    }
}
