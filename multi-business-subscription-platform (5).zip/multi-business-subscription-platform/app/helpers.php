<?php

declare(strict_types=1);

use App\Core\Csrf;
use App\Core\Flash;
use App\Core\HttpException;

function load_env(string $path): void
{
    if (!is_file($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return;
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0) {
            continue;
        }

        $parts = explode('=', $line, 2);
        if (count($parts) !== 2) {
            continue;
        }

        $key = trim($parts[0]);
        $value = trim($parts[1]);
        $value = trim($value, "\"'");

        if ($key !== '' && getenv($key) === false) {
            putenv($key . '=' . $value);
            $_ENV[$key] = $value;
            $_SERVER[$key] = $value;
        }
    }
}

function env_value(string $key, ?string $default = null): ?string
{
    $value = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);
    if ($value === false || $value === null || $value === '') {
        return $default;
    }
    return (string) $value;
}

function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function base_url_path(): string
{
    if (PHP_SAPI === 'cli') {
        return '';
    }

    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $base = rtrim(dirname($scriptName), '/');

    if ($base === '/' || $base === '.' || $base === '\\') {
        return '';
    }

    return $base;
}

function url(string $path = ''): string
{
    if ($path !== '' && preg_match('#^https?://#i', $path)) {
        return $path;
    }

    $base = base_url_path();
    $path = '/' . ltrim($path, '/');

    if ($path === '/') {
        return $base === '' ? '/' : $base . '/';
    }

    return $base . $path;
}

function asset(string $path): string
{
    return url('/assets/' . ltrim($path, '/'));
}

function upload_url(?string $path): string
{
    if (!$path) {
        return '';
    }
    return url('/' . ltrim($path, '/'));
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Csrf::token()) . '">';
}

function old(string $key, $default = '')
{
    return $_SESSION['_old'][$key] ?? $default;
}

function clear_old_input(): void
{
    unset($_SESSION['_old']);
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

function abort_request(int $statusCode = 404, string $message = ''): void
{
    throw new HttpException($statusCode, $message);
}

function slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/i', '-', $value) ?? '';
    $value = trim($value, '-');
    return $value !== '' ? $value : 'item';
}

function text_excerpt(?string $text, int $limit = 120): string
{
    $text = trim((string) $text);
    if ($text === '') {
        return '';
    }
    if (function_exists('mb_strimwidth')) {
        return mb_strimwidth($text, 0, $limit, '...', 'UTF-8');
    }
    return strlen($text) > $limit ? substr($text, 0, $limit - 3) . '...' : $text;
}

function valid_hex_color(?string $value, string $fallback): string
{
    $value = trim((string) $value);
    return preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? $value : $fallback;
}

function contrast_text_color(string $hex): string
{
    $hex = ltrim(valid_hex_color($hex, '#2563eb'), '#');
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    $luminance = (($r * 299) + ($g * 587) + ($b * 114)) / 1000;
    return $luminance > 145 ? '#0f172a' : '#ffffff';
}

function website_section_enabled(array $settings, string $section, bool $default = true): bool
{
    $visibility = json_decode((string) ($settings['section_visibility'] ?? ''), true);
    if (!is_array($visibility)) {
        return $default;
    }
    return array_key_exists($section, $visibility) ? (bool) $visibility[$section] : $default;
}

function format_money($amount, string $currency = 'INR'): string
{
    $amount = (float) ($amount ?? 0);
    $symbol = $currency === 'INR' ? '₹' : ($currency . ' ');
    return $symbol . number_format($amount, 2);
}

function format_date($date, string $fallback = '—'): string
{
    if (!$date) {
        return $fallback;
    }

    try {
        return (new DateTimeImmutable((string) $date))->format('d M Y');
    } catch (Throwable $e) {
        return $fallback;
    }
}

function format_datetime($date, string $fallback = '—'): string
{
    if (!$date) {
        return $fallback;
    }

    try {
        return (new DateTimeImmutable((string) $date))->format('d M Y, h:i A');
    } catch (Throwable $e) {
        return $fallback;
    }
}

function time_ago($date): string
{
    if (!$date) {
        return '—';
    }

    try {
        $time = new DateTimeImmutable((string) $date);
        $now = new DateTimeImmutable('now');
        $diff = $now->getTimestamp() - $time->getTimestamp();
        if ($diff < 60) {
            return 'just now';
        }
        if ($diff < 3600) {
            return floor($diff / 60) . ' min ago';
        }
        if ($diff < 86400) {
            return floor($diff / 3600) . ' hr ago';
        }
        if ($diff < 604800) {
            return floor($diff / 86400) . ' days ago';
        }
        return $time->format('d M Y');
    } catch (Throwable $e) {
        return '—';
    }
}

function status_badge(string $status): string
{
    $safeStatus = e(str_replace('_', ' ', ucfirst($status)));
    $class = 'badge';
    $map = [
        'active' => 'success',
        'approved' => 'success',
        'paid' => 'success',
        'converted' => 'success',
        'completed' => 'success',
        'expiring' => 'warning',
        'grace_period' => 'warning',
        'pending' => 'warning',
        'new' => 'info',
        'in_progress' => 'info',
        'contacted' => 'info',
        'expired' => 'danger',
        'suspended' => 'danger',
        'rejected' => 'danger',
        'failed' => 'danger',
        'cancelled' => 'muted',
        'inactive' => 'muted',
        'website_disabled' => 'muted',
        'no_subscription' => 'muted',
        'archived' => 'muted',
        'closed' => 'muted',
    ];
    $class .= ' ' . ($map[$status] ?? 'muted');
    return '<span class="' . $class . '">' . $safeStatus . '</span>';
}

function app_log(string $message, array $context = []): void
{
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $message;
    if (!empty($context)) {
        $line .= ' ' . json_encode($context, JSON_UNESCAPED_SLASHES);
    }
    $line .= PHP_EOL;
    $logFile = STORAGE_PATH . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'app.log';
    if (!is_dir(dirname($logFile))) {
        mkdir(dirname($logFile), 0775, true);
    }
    file_put_contents($logFile, $line, FILE_APPEND);
}

function flash_messages(): array
{
    return Flash::all();
}
