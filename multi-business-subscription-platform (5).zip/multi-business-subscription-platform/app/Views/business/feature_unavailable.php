<?php
$isLimit = ($reason ?? '') === 'limit_reached';
$isWebsite = !$isLimit && (($featureName ?? '') === 'Public Business Website');
$title = $isLimit ? 'Plan Limit Reached' : ($isWebsite ? 'Website Not Included' : 'Feature Not Included');
$description = $isLimit
    ? ($limitMessage ?? 'You have reached the usage limit for this feature in your current plan.')
    : (($featureName ?? 'This feature') . ' is not available in your current subscription plan.');
?>
<section class="page-header">
    <div>
        <div class="page-kicker">Plan Access</div>
        <h2 class="page-title"><?= e($title) ?></h2>
        <p class="page-description"><?= e($description) ?></p>
    </div>
    <a class="btn btn-outline" href="<?= e(url('/business/subscription')) ?>">View Plans</a>
</section>

<div class="card" style="max-width:860px;">
    <div class="card-header">
        <div>
            <h3 class="card-title"><?= $isWebsite ? 'Public website is locked' : 'Upgrade required' ?></h3>
            <p class="card-subtitle">
                <?php if ($isWebsite): ?>
                    Your website settings, branding and content are preserved, but website management and public website access stay locked until your active plan includes Public Business Website.
                <?php else: ?>
                    Contact the platform admin to upgrade or change your plan. Online self-upgrades can be added later using the same plan-feature system.
                <?php endif; ?>
            </p>
        </div>
    </div>
    <div class="actions">
        <a class="btn btn-primary" href="<?= e(url('/business/subscription')) ?>">View Plans</a>
        <a class="btn btn-outline" href="<?= e(url('/business/subscription')) ?>">Upgrade Plan</a>
        <a class="btn btn-outline" href="<?= e(url('/business')) ?>">Back to Dashboard</a>
    </div>
</div>

<?php if (!empty($plans)): ?>
<div class="grid grid-3" style="margin-top:18px;">
    <?php foreach ($plans as $plan): ?>
        <div class="card soft">
            <h3 style="margin:0 0 8px;"><?= e($plan['name']) ?></h3>
            <div class="price"><?= e(format_money($plan['monthly_price'] ?? $plan['price'], $plan['currency'])) ?></div>
            <?php if (!empty($plan['yearly_price'])): ?><div class="table-muted">Yearly: <?= e(format_money($plan['yearly_price'], $plan['currency'])) ?></div><?php endif; ?>
            <p><?= e($plan['description']) ?></p>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
