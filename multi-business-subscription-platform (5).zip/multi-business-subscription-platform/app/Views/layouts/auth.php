<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Login') ?> · Multi-Business Platform</title>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <?php $messages = flash_messages(); if ($messages): ?>
            <div class="alerts">
                <?php foreach ($messages as $message): ?>
                    <div class="alert <?= e($message['type']) ?>"><?= e($message['message']) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?= $content ?>
    </div>
</div>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
