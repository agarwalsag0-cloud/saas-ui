<?php
$active = $active ?? '';
$adminUser = $adminUser ?? [];
$adminUnreadNotifications = $adminUnreadNotifications ?? 0;
function admin_nav_active(string $key, string $active): string { return $key === $active ? 'active' : ''; }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Admin') ?> · Platform Control</title>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <a class="brand" href="<?= e(url('/admin')) ?>">
            <span class="brand-mark">SA</span>
            <span>
                <span class="brand-title">Platform Control</span>
                <span class="brand-subtitle">Super Admin Portal</span>
            </span>
        </a>
        <nav>
            <div class="nav-section-title">Overview</div>
            <a class="nav-link <?= admin_nav_active('dashboard', $active) ?>" href="<?= e(url('/admin')) ?>">📊 Dashboard</a>
            <a class="nav-link <?= admin_nav_active('businesses', $active) ?>" href="<?= e(url('/admin/businesses')) ?>">🏢 Businesses</a>
            <a class="nav-link <?= admin_nav_active('plans', $active) ?>" href="<?= e(url('/admin/plans')) ?>">💳 Subscription Plans</a>
            <a class="nav-link <?= admin_nav_active('features', $active) ?>" href="<?= e(url('/admin/features')) ?>">🧩 Feature Registry</a>
            <a class="nav-link <?= admin_nav_active('notifications', $active) ?>" href="<?= e(url('/admin/notifications')) ?>">🔔 Notifications <?php if ($adminUnreadNotifications): ?><span class="pill"><?= (int) $adminUnreadNotifications ?></span><?php endif; ?></a>
            <div class="nav-section-title">Public</div>
            <a class="nav-link" href="<?= e(url('/')) ?>" target="_blank">🌐 Portal Directory</a>
        </nav>
    </aside>
    <div class="main-wrap">
        <header class="topbar">
            <div class="actions">
                <button class="btn btn-outline sidebar-toggle" data-sidebar-toggle type="button">☰</button>
                <h1><?= e($pageTitle ?? 'Admin') ?></h1>
            </div>
            <div class="topbar-actions">
                <div class="user-chip">
                    <span class="avatar"><?= e(strtoupper(substr($adminUser['name'] ?? 'A', 0, 1))) ?></span>
                    <small><?= e($adminUser['name'] ?? 'Admin') ?></small>
                </div>
                <form method="post" action="<?= e(url('/logout')) ?>">
                    <?= csrf_field() ?>
                    <button class="btn btn-outline btn-sm" type="submit">Logout</button>
                </form>
            </div>
        </header>
        <main class="content">
            <?php $messages = flash_messages(); if ($messages): ?>
                <div class="alerts">
                    <?php foreach ($messages as $message): ?>
                        <div class="alert <?= e($message['type']) ?>"><?= e($message['message']) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?= $content ?>
        </main>
    </div>
</div>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
