<?php
$active = $active ?? '';
$businessUnreadNotifications = $businessUnreadNotifications ?? 0;
$featureAccess = $featureAccess ?? [];
$canFeature = fn(string $identifier): bool => isset($featureAccess[$identifier]);
$canAnyFeature = fn(array $identifiers): bool => (bool) array_intersect($identifiers, array_keys($featureAccess));
function business_nav_active(string $key, string $active): string { return $key === $active ? 'active' : ''; }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Business') ?> · <?= e($business['name'] ?? 'Business Portal') ?></title>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar business-sidebar">
        <a class="brand" href="<?= e(url('/business')) ?>">
            <span class="brand-mark"><?= e(strtoupper(substr($business['name'] ?? 'B', 0, 1))) ?></span>
            <span>
                <span class="brand-title"><?= e($business['name'] ?? 'Business') ?></span>
                <span class="brand-subtitle">Business Management</span>
            </span>
        </a>
        <nav>
            <div class="nav-section-title">Manage</div>
            <a class="nav-link <?= business_nav_active('dashboard', $active) ?>" href="<?= e(url('/business')) ?>">📈 Dashboard</a>
            <?php if ($canFeature('business_profile')): ?><a class="nav-link <?= business_nav_active('profile', $active) ?>" href="<?= e(url('/business/profile')) ?>">🏪 Profile</a><?php endif; ?>
            <?php if ($canFeature('public_website')): ?><a class="nav-link <?= business_nav_active('website', $active) ?>" href="<?= e(url('/business/website')) ?>">🎨 Website Settings</a><?php else: ?><a class="nav-link <?= business_nav_active('website', $active) ?>" href="<?= e(url('/business/website')) ?>">🔒 Website</a><?php endif; ?>
            <?php if ($canFeature('categories')): ?><a class="nav-link <?= business_nav_active('categories', $active) ?>" href="<?= e(url('/business/categories')) ?>">🗂 Categories</a><?php endif; ?>
            <?php if ($canAnyFeature(['product_management','service_management'])): ?><a class="nav-link <?= business_nav_active('listings', $active) ?>" href="<?= e(url('/business/listings')) ?>">🧾 Products & Services</a><?php endif; ?>
            <?php if ($canFeature('offers')): ?><a class="nav-link <?= business_nav_active('offers', $active) ?>" href="<?= e(url('/business/offers')) ?>">🏷 Offers</a><?php endif; ?>
            <?php if ($canFeature('enquiries')): ?><a class="nav-link <?= business_nav_active('enquiries', $active) ?>" href="<?= e(url('/business/enquiries')) ?>">💬 Enquiries</a><?php endif; ?>
            <?php if ($canFeature('orders')): ?><a class="nav-link <?= business_nav_active('orders', $active) ?>" href="<?= e(url('/business/orders')) ?>">📦 Orders/Requests</a><?php endif; ?>
            <div class="nav-section-title">Account</div>
            <a class="nav-link <?= business_nav_active('subscription', $active) ?>" href="<?= e(url('/business/subscription')) ?>">💳 Subscription</a>
            <?php if ($canFeature('notifications')): ?><a class="nav-link <?= business_nav_active('notifications', $active) ?>" href="<?= e(url('/business/notifications')) ?>">🔔 Notifications <?php if ($businessUnreadNotifications): ?><span class="pill"><?= (int) $businessUnreadNotifications ?></span><?php endif; ?></a><?php endif; ?>
            <?php if ($canFeature('public_website')): ?><a class="nav-link" href="<?= e(url('/p/' . ($business['slug'] ?? ''))) ?>" target="_blank">🌐 View My Website</a><?php endif; ?>
        </nav>
    </aside>
    <div class="main-wrap">
        <header class="topbar">
            <div class="actions">
                <button class="btn btn-outline sidebar-toggle" data-sidebar-toggle type="button">☰</button>
                <h1><?= e($pageTitle ?? 'Business') ?></h1>
            </div>
            <div class="topbar-actions">
                <?= status_badge($effectiveSubscriptionStatus ?? 'unknown') ?>
                <div class="user-chip">
                    <span class="avatar"><?= e(strtoupper(substr($businessUser['name'] ?? 'U', 0, 1))) ?></span>
                    <small><?= e($businessUser['name'] ?? 'User') ?></small>
                </div>
                <form method="post" action="<?= e(url('/logout')) ?>">
                    <?= csrf_field() ?>
                    <button class="btn btn-outline btn-sm" type="submit">Logout</button>
                </form>
            </div>
        </header>
        <main class="content">
            <?php if (!$portalAllowed && ($active ?? '') !== 'subscription'): ?>
                <div class="alert warning"><strong>Restricted:</strong>&nbsp; Your current status is <?= e(str_replace('_', ' ', $effectiveSubscriptionStatus ?? 'restricted')) ?>. Some actions are disabled until the subscription/business is active.</div>
            <?php endif; ?>
            <?php $messages = flash_messages(); if ($messages): ?>
                <div class="alerts">
                    <?php foreach ($messages as $message): ?>
                        <div class="alert <?= e($message['type']) ?>"><?= e($message['message']) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?= $content ?>
        </main>
    </div>
</div>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
