<?php
$settings = $settings ?? [];
$business = $business ?? ['name' => 'Business Website', 'slug' => ''];
$primary = valid_hex_color($settings['primary_color'] ?? ($settings['theme_color'] ?? '#2563eb'), '#2563eb');
$secondary = valid_hex_color($settings['secondary_color'] ?? '#0f172a', '#0f172a');
$accent = valid_hex_color($settings['accent_color'] ?? '#f97316', '#f97316');
$buttonText = contrast_text_color($primary);
$businessName = $business['name'] ?? 'Business Website';
$metaDescription = $seoDescription ?? ($settings['seo_description'] ?? text_excerpt($business['description'] ?? ($business['tagline'] ?? ''), 160));
$layoutClass = 'website-layout-' . preg_replace('/[^a-z_\-]/', '', (string) ($settings['layout_style'] ?? 'classic'));
$bgClass = 'website-bg-' . preg_replace('/[^a-z_\-]/', '', (string) ($settings['background_style'] ?? 'light'));
$buttonClass = 'website-buttons-' . preg_replace('/[^a-z_\-]/', '', (string) ($settings['button_style'] ?? 'rounded'));
$textClass = 'website-text-' . preg_replace('/[^a-z_\-]/', '', (string) ($settings['text_style'] ?? 'system'));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? $businessName) ?></title>
    <meta name="description" content="<?= e($metaDescription ?: $businessName) ?>">
    <link rel="canonical" href="<?= e(url('/p/' . ($business['slug'] ?? ''))) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
    <style>
        :root {
            --site-primary: <?= e($primary) ?>;
            --site-secondary: <?= e($secondary) ?>;
            --site-accent: <?= e($accent) ?>;
            --site-button-text: <?= e($buttonText) ?>;
        }
    </style>
</head>
<body class="website-page <?= e($layoutClass . ' ' . $bgClass . ' ' . $buttonClass . ' ' . $textClass) ?>">
<header class="website-header">
    <a class="website-brand" href="<?= e(url('/p/' . ($business['slug'] ?? ''))) ?>">
        <?php if (!empty($business['logo_path'])): ?>
            <img src="<?= e(upload_url($business['logo_path'])) ?>" alt="<?= e($businessName) ?> logo">
        <?php else: ?>
            <span class="website-brand-mark"><?= e(strtoupper(substr($businessName, 0, 1))) ?></span>
        <?php endif; ?>
        <span>
            <strong><?= e($businessName) ?></strong>
            <?php if (!empty($business['category'])): ?><small><?= e($business['category']) ?></small><?php endif; ?>
        </span>
    </a>
    <nav class="website-nav">
        <a href="<?= e(url('/p/' . ($business['slug'] ?? '') . '#about')) ?>">About</a>
        <a href="<?= e(url('/p/' . ($business['slug'] ?? '') . '#listings')) ?>">Products/Services</a>
        <a href="<?= e(url('/p/' . ($business['slug'] ?? '') . '#contact')) ?>">Contact</a>
        <?php if (!empty($business['phone'])): ?><a class="site-btn site-btn-small" href="tel:<?= e($business['phone']) ?>">Call Now</a><?php endif; ?>
    </nav>
</header>

<?php $messages = flash_messages(); if ($messages): ?>
    <div class="website-container" style="padding-top:18px;padding-bottom:0;">
        <div class="alerts">
            <?php foreach ($messages as $message): ?>
                <div class="alert <?= e($message['type']) ?>"><?= e($message['message']) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<main>
    <?= $content ?>
</main>

<footer class="website-footer">
    <div>
        <strong><?= e($businessName) ?></strong>
        <?php if (!empty($business['tagline'])): ?><p><?= e($business['tagline']) ?></p><?php endif; ?>
    </div>
    <div class="website-footer-links">
        <?php if (!empty($business['phone'])): ?><span><?= e($business['phone']) ?></span><?php endif; ?>
        <?php if (!empty($business['email'])): ?><span><?= e($business['email']) ?></span><?php endif; ?>
        <?php if (!empty($business['city'])): ?><span><?= e($business['city']) ?></span><?php endif; ?>
    </div>
</footer>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
