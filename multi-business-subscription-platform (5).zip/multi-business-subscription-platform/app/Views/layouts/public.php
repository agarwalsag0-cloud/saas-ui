<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Business Portal') ?> · Multi-Business Platform</title>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="public-body">
<nav class="public-nav">
    <a class="public-brand" href="<?= e(url('/')) ?>">
        <span class="brand-mark">MB</span>
        <span>Multi-Business Platform</span>
    </a>
    <div class="actions">
        <a class="btn btn-outline btn-sm" href="<?= e(url('/')) ?>">Directory</a>
        <a class="btn btn-outline btn-sm" href="<?= e(url('/register-business')) ?>">Register Business</a>
        <a class="btn btn-primary btn-sm" href="<?= e(url('/login')) ?>">Portal Login</a>
    </div>
</nav>
<main class="public-main">
    <?php $messages = flash_messages(); if ($messages): ?>
        <div class="public-section" style="padding-bottom:0;">
            <div class="alerts">
                <?php foreach ($messages as $message): ?>
                    <div class="alert <?= e($message['type']) ?>"><?= e($message['message']) ?></div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    <?= $content ?>
</main>
<footer class="public-footer">
    <small>Powered by Multi-Business Subscription Platform. Each public portal is an isolated tenant under one central SaaS system.</small>
</footer>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
