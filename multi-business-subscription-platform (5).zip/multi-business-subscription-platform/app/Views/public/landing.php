<section class="hero">
    <div class="hero-content">
        <div class="page-kicker" style="color:#bfdbfe;">Multi-tenant SaaS foundation</div>
        <h1>Independent business websites under one secure platform.</h1>
        <p>Create your business account, manage your profile, listings and offers, and automatically get a professional public website.</p>
        <div class="actions" style="margin-top:22px;"><a class="btn btn-primary" href="<?= e(url('/register-business')) ?>">Register business</a><a class="btn btn-outline" style="color:#fff;border-color:rgba(255,255,255,.35);" href="<?= e(url('/login')) ?>">Login to portal</a></div>
    </div>
</section>

<section class="public-section">
    <div class="card-header">
        <div><h2 class="card-title" style="font-size:26px;">Business website directory</h2><p class="card-subtitle">Approved businesses with active websites and subscriptions appear here.</p></div>
    </div>
    <div class="listing-grid">
        <?php foreach ($businesses as $business): ?>
            <article class="listing-card">
                <div class="listing-image">
                    <?php if ($business['cover_path']): ?><img src="<?= e(upload_url($business['cover_path'])) ?>" alt="<?= e($business['name']) ?> cover"><?php else: ?><?= e($business['category']) ?><?php endif; ?>
                </div>
                <div class="listing-body">
                    <?php if ($business['logo_path']): ?><img src="<?= e(upload_url($business['logo_path'])) ?>" alt="<?= e($business['name']) ?> logo" style="width:58px;height:58px;border-radius:16px;object-fit:cover;margin-top:-46px;border:3px solid #fff;box-shadow:0 8px 20px rgba(15,23,42,.12);"><?php endif; ?>
                    <h3 style="margin:0;"><?= e($business['name']) ?></h3>
                    <div class="table-muted"><?= e($business['category']) ?> · <?= e(trim(($business['city'] ?? '') . ', ' . ($business['state'] ?? ''), ', ')) ?></div>
                    <p><?= e(text_excerpt((string) ($business['tagline'] ?: ($business['description'] ?? '')), 130)) ?></p>
                    <a class="btn btn-primary" href="<?= e(url('/p/' . $business['slug'])) ?>">Visit website</a>
                </div>
            </article>
        <?php endforeach; if (!$businesses): ?>
            <div class="empty-state" style="grid-column:1/-1;"><strong>No public businesses yet</strong>Import the demo seed or approve a business from Super Admin.</div>
        <?php endif; ?>
    </div>
</section>
