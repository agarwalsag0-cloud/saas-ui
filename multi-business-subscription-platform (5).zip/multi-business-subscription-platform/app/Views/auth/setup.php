<div class="card">
    <div class="brand auth-logo">
        <span class="brand-mark">SA</span>
        <span>
            <span class="brand-title" style="color:var(--text);">Initial Super Admin Setup</span>
            <span class="brand-subtitle" style="color:var(--muted);">Create your own platform owner credentials</span>
        </span>
    </div>
    <h1 class="page-title" style="font-size:28px;">Create Super Admin</h1>
    <p class="page-description" style="margin-bottom:22px;">No default admin is required. Set the first Super Admin here after importing the database.</p>
    <form method="post" action="<?= e(url('/setup')) ?>" autocomplete="off">
        <?= csrf_field() ?>
        <div class="form-row">
            <label for="name">Name</label>
            <input id="name" type="text" name="name" value="<?= e(old('name')) ?>" required autofocus>
        </div>
        <div class="form-row">
            <label for="email">Email</label>
            <input id="email" type="email" name="email" value="<?= e(old('email')) ?>" required>
        </div>
        <div class="form-row">
            <label for="password">Password</label>
            <input id="password" type="password" name="password" minlength="8" required>
        </div>
        <div class="form-row">
            <label for="password_confirmation">Confirm password</label>
            <input id="password_confirmation" type="password" name="password_confirmation" minlength="8" required>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Create Super Admin</button>
    </form>
    <p class="help-text" style="margin-top:14px;">After this, new business owners can be added from Super Admin or through public registration.</p>
</div>
