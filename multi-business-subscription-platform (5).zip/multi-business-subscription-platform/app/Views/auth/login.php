<div class="card">
    <div class="brand auth-logo">
        <span class="brand-mark">MB</span>
        <span>
            <span class="brand-title" style="color:var(--text);">Multi-Business Platform</span>
            <span class="brand-subtitle" style="color:var(--muted);">Secure portal access</span>
        </span>
    </div>
    <h1 class="page-title" style="font-size:28px;">Sign in</h1>
    <p class="page-description" style="margin-bottom:22px;">Use the Super Admin credentials you created during setup, or the Business Owner credentials created from Super Admin / registration.</p>
    <form method="post" action="<?= e(url('/login')) ?>" autocomplete="on">
        <?= csrf_field() ?>
        <div class="form-row">
            <label for="email">Email</label>
            <input id="email" type="email" name="email" value="<?= e(old('email')) ?>" required autofocus>
        </div>
        <div class="form-row">
            <label for="password">Password</label>
            <input id="password" type="password" name="password" required>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Login securely</button>
    </form>
    <div class="actions" style="margin-top:18px;justify-content:center;">
        <a class="btn btn-outline btn-sm" href="<?= e(url('/register-business')) ?>">Register business</a>
        <a class="btn btn-outline btn-sm" href="<?= e(url('/setup')) ?>">Initial admin setup</a>
    </div>
</div>
