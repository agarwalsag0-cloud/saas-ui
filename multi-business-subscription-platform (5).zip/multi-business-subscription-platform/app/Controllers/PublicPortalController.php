<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Flash;
use App\Core\HttpException;
use App\Core\Validator;
use App\Services\ActivityLogger;
use App\Services\FeatureService;
use App\Services\NotificationService;
use App\Services\SubscriptionService;
use PDO;

class PublicPortalController extends Controller
{
    public function landing(): void
    {
        $stmt = Database::pdo()->query(
            'SELECT b.id, b.name, b.slug, b.category, b.tagline, b.city, b.state, b.description, b.logo_path, b.cover_path,
                    COALESCE(w.website_enabled, 1) AS website_enabled,
                    COALESCE(w.show_in_directory, 1) AS show_in_directory
             FROM businesses b
             LEFT JOIN business_settings w ON w.business_id = b.id
             WHERE b.status IN ("active", "approved")
               AND COALESCE(w.website_enabled, 1) = 1
               AND COALESCE(w.show_in_directory, 1) = 1
               AND EXISTS (
                   SELECT 1 FROM business_subscriptions bs
                   INNER JOIN subscription_plan_features spf ON spf.plan_id = bs.plan_id AND spf.enabled = 1
                   INNER JOIN platform_features pf ON pf.id = spf.feature_id AND pf.identifier = "public_website" AND pf.is_active = 1 AND pf.available_for_plans = 1
                   WHERE bs.business_id = b.id
                     AND bs.status IN ("active", "trialing")
                     AND (bs.expires_at >= CURDATE() OR (bs.grace_ends_at IS NOT NULL AND bs.grace_ends_at >= CURDATE()))
               )
             ORDER BY b.created_at DESC
             LIMIT 12'
        );

        $this->render('public.landing', [
            'pageTitle' => 'Business Websites',
            'businesses' => $stmt->fetchAll(),
        ], 'layouts/public');
    }

    public function portal(string $slug): void
    {
        $business = $this->businessBySlug($slug);
        $businessId = (int) $business['id'];
        $settings = $this->settingsForBusiness($businessId);
        $subscription = SubscriptionService::current($businessId);
        $featureAccess = FeatureService::featuresForBusiness($businessId, $business, $subscription);
        $effectiveStatus = SubscriptionService::effectiveStatus($business, $subscription);

        if (empty($settings['website_enabled']) || empty($featureAccess['public_website']) || !SubscriptionService::canUsePortal($business, $subscription)) {
            $this->render('public.unavailable', [
                'pageTitle' => $business['name'] . ' unavailable',
                'business' => $business,
                'settings' => $settings,
                'subscription' => $subscription,
                'effectiveStatus' => empty($settings['website_enabled']) ? 'website_disabled' : (empty($featureAccess['public_website']) ? 'feature_not_included' : $effectiveStatus),
            ], 'layouts/website');
            return;
        }

        $canCategories = isset($featureAccess['categories']);
        $canListings = isset($featureAccess['product_management']) || isset($featureAccess['service_management']);
        $canOffers = isset($featureAccess['offers']);
        $canEnquiries = isset($featureAccess['enquiries']);
        $canOrders = isset($featureAccess['orders']);

        $categorySlug = $canCategories ? trim((string) ($_GET['category'] ?? '')) : '';
        $params = [$businessId];
        $where = 'l.business_id = ? AND l.status = "active" AND l.visible_on_website = 1';
        $typeWhere = '';
        $offerTypeWhere = '';
        if (isset($featureAccess['product_management']) && !isset($featureAccess['service_management'])) {
            $typeWhere = ' AND l.type = "product"';
            $offerTypeWhere = ' AND (o.listing_id IS NULL OR l.type = "product")';
            $where .= $typeWhere;
        } elseif (!isset($featureAccess['product_management']) && isset($featureAccess['service_management'])) {
            $typeWhere = ' AND l.type <> "product"';
            $offerTypeWhere = ' AND (o.listing_id IS NULL OR l.type <> "product")';
            $where .= $typeWhere;
        }

        if ($categorySlug !== '') {
            $where .= ' AND c.slug = ? AND c.visible_on_website = 1 AND c.is_active = 1';
            $params[] = $categorySlug;
        }

        $categoriesStmt = Database::pdo()->prepare(
            'SELECT c.*,
                    (SELECT COUNT(*) FROM listings l WHERE l.business_id = c.business_id AND l.category_id = c.id AND l.status = "active" AND l.visible_on_website = 1' . $typeWhere . ') AS public_listing_count
             FROM categories c
             WHERE c.business_id = ? AND c.is_active = 1 AND c.visible_on_website = 1
             ORDER BY c.sort_order ASC, c.name ASC'
        );
        $categoriesStmt->execute([$businessId]);

        $listingsStmt = Database::pdo()->prepare(
            'SELECT l.*, c.name AS category_name, c.slug AS category_slug
             FROM listings l
             LEFT JOIN categories c ON c.id = l.category_id AND c.business_id = l.business_id
             WHERE ' . $where . '
             ORDER BY l.is_featured DESC, l.created_at DESC
             LIMIT 48'
        );
        $listingsStmt->execute($params);

        $featuredStmt = Database::pdo()->prepare(
            'SELECT l.*, c.name AS category_name
             FROM listings l
             LEFT JOIN categories c ON c.id = l.category_id AND c.business_id = l.business_id
             WHERE l.business_id = ? AND l.status = "active" AND l.visible_on_website = 1 AND l.is_featured = 1' . $typeWhere . '
             ORDER BY l.updated_at DESC
             LIMIT 6'
        );
        $featuredStmt->execute([$businessId]);

        $offersStmt = Database::pdo()->prepare(
            'SELECT o.*, l.title AS listing_title, l.slug AS listing_slug
             FROM offers o
             LEFT JOIN listings l ON l.id = o.listing_id AND l.business_id = o.business_id
             WHERE o.business_id = ? AND o.is_active = 1 AND o.visible_on_website = 1
               AND (o.listing_id IS NULL OR l.visible_on_website = 1)' . $offerTypeWhere . '
               AND (o.start_at IS NULL OR o.start_at <= CURDATE())
               AND (o.end_at IS NULL OR o.end_at >= CURDATE())
             ORDER BY o.created_at DESC
             LIMIT 8'
        );
        $offersStmt->execute([$businessId]);

        $this->render('public.portal', [
            'pageTitle' => $settings['seo_title'] ?: $business['name'],
            'seoDescription' => $settings['seo_description'] ?: text_excerpt($business['description'] ?: ($business['tagline'] ?? ''), 160),
            'business' => $business,
            'settings' => array_merge($settings, [
                'allow_public_enquiries' => $canEnquiries ? (int) $settings['allow_public_enquiries'] : 0,
                'allow_public_orders' => $canOrders ? (int) $settings['allow_public_orders'] : 0,
            ]),
            'categories' => $canCategories ? $categoriesStmt->fetchAll() : [],
            'featuredListings' => ($canListings && isset($featureAccess['featured_listings'])) ? $featuredStmt->fetchAll() : [],
            'listings' => $canListings ? $listingsStmt->fetchAll() : [],
            'offers' => $canOffers ? $offersStmt->fetchAll() : [],
            'currentCategory' => $categorySlug,
            'featureAccess' => $featureAccess,
        ], 'layouts/website');
    }

    public function listing(string $slug, string $listingSlug): void
    {
        $business = $this->businessBySlug($slug);
        $businessId = (int) $business['id'];
        $settings = $this->settingsForBusiness($businessId);
        $subscription = SubscriptionService::current($businessId);
        $featureAccess = FeatureService::featuresForBusiness($businessId, $business, $subscription);

        if (empty($settings['website_enabled']) || empty($featureAccess['public_website']) || (!isset($featureAccess['product_management']) && !isset($featureAccess['service_management'])) || !SubscriptionService::canUsePortal($business, $subscription)) {
            throw new HttpException(404);
        }

        if (empty($featureAccess['enquiries'])) {
            $settings['allow_public_enquiries'] = 0;
        }
        if (empty($featureAccess['orders'])) {
            $settings['allow_public_orders'] = 0;
        }
        $typeWhere = '';
        if (isset($featureAccess['product_management']) && !isset($featureAccess['service_management'])) {
            $typeWhere = ' AND type = "product"';
        } elseif (!isset($featureAccess['product_management']) && isset($featureAccess['service_management'])) {
            $typeWhere = ' AND type <> "product"';
        }

        $stmt = Database::pdo()->prepare(
            'SELECT l.*, c.name AS category_name
             FROM listings l
             LEFT JOIN categories c ON c.id = l.category_id AND c.business_id = l.business_id
             WHERE l.business_id = ? AND l.slug = ? AND l.status = "active" AND l.visible_on_website = 1
             LIMIT 1'
        );
        $stmt->execute([$businessId, $listingSlug]);
        $listing = $stmt->fetch();

        if (!$listing) {
            throw new HttpException(404);
        }
        if ($listing['type'] === 'product' && empty($featureAccess['product_management'])) {
            throw new HttpException(404);
        }
        if ($listing['type'] !== 'product' && empty($featureAccess['service_management'])) {
            throw new HttpException(404);
        }

        $relatedStmt = Database::pdo()->prepare(
            'SELECT id, title, slug, price, price_label, image_path, type, short_description
             FROM listings
             WHERE business_id = ? AND status = "active" AND visible_on_website = 1 AND id <> ?' . $typeWhere . '
             ORDER BY is_featured DESC, created_at DESC
             LIMIT 4'
        );
        $relatedStmt->execute([$businessId, (int) $listing['id']]);

        $this->render('public.listing', [
            'pageTitle' => $listing['title'] . ' - ' . $business['name'],
            'seoDescription' => text_excerpt($listing['short_description'] ?: $listing['description'] ?: $business['description'], 160),
            'business' => $business,
            'settings' => $settings,
            'listing' => $listing,
            'relatedListings' => $relatedStmt->fetchAll(),
            'featureAccess' => $featureAccess,
        ], 'layouts/website');
    }

    public function submitEnquiry(string $slug): void
    {
        $this->verifyCsrf();
        $business = $this->businessBySlug($slug);
        $businessId = (int) $business['id'];
        $settings = $this->settingsForBusiness($businessId);
        $subscription = SubscriptionService::current($businessId);
        $featureAccess = FeatureService::featuresForBusiness($businessId, $business, $subscription);

        if (empty($settings['website_enabled']) || empty($featureAccess['public_website']) || empty($featureAccess['enquiries']) || empty($settings['allow_public_enquiries']) || !SubscriptionService::canUsePortal($business, $subscription)) {
            throw new HttpException(403, 'This website is not accepting enquiries right now.');
        }

        $validator = (new Validator())
            ->required('name', 'Name')
            ->required('phone', 'Phone')
            ->required('message', 'Message')
            ->email('email', 'Email')
            ->max('message', 'Message', 2000);

        if (!$validator->passes()) {
            $this->flashValidationErrors($validator->errors());
            $this->redirect('/p/' . $business['slug']);
        }

        $listing = $this->tenantListing($businessId, (int) ($_POST['listing_id'] ?? 0), $featureAccess);
        $requestedItem = $listing['title'] ?? (trim((string) ($_POST['requested_item'] ?? '')) ?: null);

        $pdo = Database::pdo();
        $pdo->beginTransaction();
        $customerId = $this->findOrCreateCustomer($businessId);

        $stmt = $pdo->prepare(
            'INSERT INTO enquiries
             (business_id, customer_id, listing_id, name, phone, email, message, requested_item, status, source, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, "new", "public_portal", NOW(), NOW())'
        );
        $stmt->execute([
            $businessId,
            $customerId,
            $listing['id'] ?? null,
            trim((string) $_POST['name']),
            trim((string) $_POST['phone']),
            trim((string) ($_POST['email'] ?? '')) ?: null,
            trim((string) $_POST['message']),
            $requestedItem,
        ]);
        $enquiryId = (int) $pdo->lastInsertId();

        $history = $pdo->prepare('INSERT INTO enquiry_status_history (enquiry_id, business_id, old_status, new_status, note, changed_by, created_at) VALUES (?, ?, NULL, "new", "Created from public website", NULL, NOW())');
        $history->execute([$enquiryId, $businessId]);
        $pdo->commit();

        NotificationService::create('business', 'new_enquiry', 'New website enquiry received', 'A customer submitted an enquiry through your public website.', $businessId, null, 'enquiry', $enquiryId);
        NotificationService::create('super_admin', 'new_enquiry', 'New enquiry on ' . $business['name'], 'A public website enquiry was submitted.', $businessId, null, 'enquiry', $enquiryId);
        ActivityLogger::log('public_website_enquiry_created', 'enquiry', $enquiryId, $businessId);

        Flash::success('Thank you. Your enquiry has been submitted.');
        $this->redirect('/p/' . $business['slug']);
    }

    public function submitOrder(string $slug): void
    {
        $this->verifyCsrf();
        $business = $this->businessBySlug($slug);
        $businessId = (int) $business['id'];
        $settings = $this->settingsForBusiness($businessId);
        $subscription = SubscriptionService::current($businessId);
        $featureAccess = FeatureService::featuresForBusiness($businessId, $business, $subscription);

        if (empty($settings['website_enabled']) || empty($featureAccess['public_website']) || empty($featureAccess['orders']) || empty($settings['allow_public_orders']) || !SubscriptionService::canUsePortal($business, $subscription)) {
            throw new HttpException(403, 'This website is not accepting requests right now.');
        }

        $validator = (new Validator())
            ->required('name', 'Name')
            ->required('phone', 'Phone')
            ->required('details', 'Request details')
            ->email('email', 'Email')
            ->in('request_type', 'Request type', ['product_order', 'service_request', 'booking_request', 'package_enquiry', 'custom_request']);

        if (!$validator->passes()) {
            $this->flashValidationErrors($validator->errors());
            $this->redirect('/p/' . $business['slug']);
        }

        $requestType = (string) ($_POST['request_type'] ?? 'custom_request');
        $this->guardPublicRequestType($requestType, $featureAccess);

        $listing = $this->tenantListing($businessId, (int) ($_POST['listing_id'] ?? 0), $featureAccess);
        $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
        $total = null;
        if ($listing && $listing['price'] !== null && $listing['price'] !== '') {
            $total = (float) $listing['price'] * $quantity;
        }

        $pdo = Database::pdo();
        $pdo->beginTransaction();
        $customerId = $this->findOrCreateCustomer($businessId);
        $orderNumber = $this->generateOrderNumber($businessId);

        $stmt = $pdo->prepare(
            'INSERT INTO orders
             (business_id, customer_id, listing_id, order_number, request_type, customer_name, phone, email, details, quantity, total_amount, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "new", NOW(), NOW())'
        );
        $stmt->execute([
            $businessId,
            $customerId,
            $listing['id'] ?? null,
            $orderNumber,
            $requestType,
            trim((string) $_POST['name']),
            trim((string) $_POST['phone']),
            trim((string) ($_POST['email'] ?? '')) ?: null,
            trim((string) $_POST['details']),
            $quantity,
            $total,
        ]);
        $orderId = (int) $pdo->lastInsertId();

        $history = $pdo->prepare('INSERT INTO order_status_history (order_id, business_id, old_status, new_status, note, changed_by, created_at) VALUES (?, ?, NULL, "new", "Created from public website", NULL, NOW())');
        $history->execute([$orderId, $businessId]);
        $pdo->commit();

        NotificationService::create('business', 'new_order', 'New website order/request received', 'A customer submitted an order or request through your public website.', $businessId, null, 'order', $orderId);
        NotificationService::create('super_admin', 'new_order', 'New request on ' . $business['name'], 'A public website order/request was submitted.', $businessId, null, 'order', $orderId);
        ActivityLogger::log('public_website_order_created', 'order', $orderId, $businessId);

        Flash::success('Your request has been submitted. Reference: ' . $orderNumber);
        $this->redirect('/p/' . $business['slug']);
    }

    private function businessBySlug(string $slug): array
    {
        $stmt = Database::pdo()->prepare('SELECT * FROM businesses WHERE slug = ? LIMIT 1');
        $stmt->execute([$slug]);
        $business = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$business || in_array($business['status'], ['rejected', 'archived'], true)) {
            throw new HttpException(404);
        }
        return $business;
    }

    private function settingsForBusiness(int $businessId): array
    {
        $stmt = Database::pdo()->prepare('SELECT * FROM business_settings WHERE business_id = ? LIMIT 1');
        $stmt->execute([$businessId]);
        $settings = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        return array_merge([
            'website_enabled' => 1,
            'show_in_directory' => 1,
            'allow_public_enquiries' => 1,
            'allow_public_orders' => 1,
            'theme_preset' => 'modern',
            'layout_style' => 'classic',
            'background_style' => 'light',
            'button_style' => 'rounded',
            'text_style' => 'system',
            'primary_color' => $settings['theme_color'] ?? '#2563eb',
            'secondary_color' => '#0f172a',
            'accent_color' => '#f97316',
            'section_visibility' => null,
            'seo_title' => null,
            'seo_description' => null,
        ], $settings);
    }

    private function guardPublicRequestType(string $requestType, array $featureAccess): void
    {
        if ($requestType === 'product_order' && empty($featureAccess['product_management'])) {
            throw new HttpException(403, 'Product orders are not included in this business plan.');
        }
        if (in_array($requestType, ['service_request', 'package_enquiry', 'custom_request'], true) && empty($featureAccess['service_management'])) {
            throw new HttpException(403, 'Service requests are not included in this business plan.');
        }
        if ($requestType === 'service_request' && empty($featureAccess['service_requests'])) {
            throw new HttpException(403, 'Service request workflows are not included in this business plan.');
        }
        if ($requestType === 'booking_request' && (empty($featureAccess['service_management']) || empty($featureAccess['booking_requests']))) {
            throw new HttpException(403, 'Booking requests are not included in this business plan.');
        }
    }

    private function tenantListing(int $businessId, int $listingId, array $featureAccess = []): ?array
    {
        if ($listingId <= 0) {
            return null;
        }
        $stmt = Database::pdo()->prepare('SELECT * FROM listings WHERE id = ? AND business_id = ? AND status = "active" AND visible_on_website = 1 LIMIT 1');
        $stmt->execute([$listingId, $businessId]);
        $listing = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$listing) {
            throw new HttpException(403, 'Invalid listing for this business website.');
        }
        if (($listing['type'] ?? '') === 'product' && empty($featureAccess['product_management'])) {
            throw new HttpException(403, 'Product requests are not included in this business plan.');
        }
        if (($listing['type'] ?? '') !== 'product' && empty($featureAccess['service_management'])) {
            throw new HttpException(403, 'Service requests are not included in this business plan.');
        }
        return $listing;
    }

    private function findOrCreateCustomer(int $businessId): int
    {
        $name = trim((string) ($_POST['name'] ?? ''));
        $phone = trim((string) ($_POST['phone'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));

        if ($phone !== '') {
            $stmt = Database::pdo()->prepare('SELECT id FROM customers WHERE business_id = ? AND phone = ? LIMIT 1');
            $stmt->execute([$businessId, $phone]);
            $existing = $stmt->fetchColumn();
            if ($existing) {
                return (int) $existing;
            }
        }

        if ($email !== '') {
            $stmt = Database::pdo()->prepare('SELECT id FROM customers WHERE business_id = ? AND email = ? LIMIT 1');
            $stmt->execute([$businessId, $email]);
            $existing = $stmt->fetchColumn();
            if ($existing) {
                return (int) $existing;
            }
        }

        $stmt = Database::pdo()->prepare('INSERT INTO customers (business_id, name, phone, email, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())');
        $stmt->execute([$businessId, $name, $phone, $email ?: null]);
        return (int) Database::pdo()->lastInsertId();
    }

    private function generateOrderNumber(int $businessId): string
    {
        do {
            $number = 'REQ-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
            $stmt = Database::pdo()->prepare('SELECT id FROM orders WHERE business_id = ? AND order_number = ? LIMIT 1');
            $stmt->execute([$businessId, $number]);
        } while ($stmt->fetch());

        return $number;
    }
}
